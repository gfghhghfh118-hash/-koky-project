"use client";

export default function ReferralLoading() {
    return <div className="p-8 text-center text-muted-foreground">Loading...</div>;
}
